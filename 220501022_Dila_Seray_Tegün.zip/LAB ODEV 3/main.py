import os
from classandfunction import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QGraphicsScene, QGraphicsView, QGraphicsLineItem, QApplication

Not_gate_number=1
Buffer_gate_number=1
AND_gate_number=1
OR_gate_number=1
NAND_gate_number=1
NOR_gate_number=1
XOR_gate_number=1
XNOR_gate_number=1
Giris_gate_number=1
cikis_gate_number=1
Dugum_number=1
led_number=1



class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setEnabled(True)
        MainWindow.resize(1520, 770)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(0, 0, 1271, 771))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.yerlestirme_alan = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.yerlestirme_alan.setContentsMargins(0, 0, 0, 0)
        self.yerlestirme_alan.setObjectName("yerlestirme_alan")
        self.resimciz=DrawingArea()
        
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(1360, 0, 91, 20))
        self.label.setObjectName("label")
        self.obje_id = QtWidgets.QFrame(self.centralwidget)
        self.obje_id.setGeometry(QtCore.QRect(1259, 0, 21, 741))
        self.obje_id.setFrameShape(QtWidgets.QFrame.VLine)
        self.obje_id.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.obje_id.setObjectName("obje_id")
        self.line_2 = QtWidgets.QFrame(self.centralwidget)
        self.line_2.setGeometry(QtCore.QRect(1350, 240, 161, 20))
        self.line_2.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(1380, 260, 111, 20))
        self.label_4.setObjectName("label_4")
        self.duzenle_radio = QtWidgets.QRadioButton(self.centralwidget)
        self.duzenle_radio.setGeometry(QtCore.QRect(1380, 350, 82, 17))
        self.duzenle_radio.setObjectName("duzenle_radio")
        self.sabitle_radio = QtWidgets.QRadioButton(self.centralwidget)
        self.sabitle_radio.setGeometry(QtCore.QRect(1380, 380, 82, 17))
        self.sabitle_radio.setObjectName("sabitle_radio")
        self.duzenlencekobje_id = QtWidgets.QLineEdit(self.centralwidget)
        self.duzenlencekobje_id.setGeometry(QtCore.QRect(1370, 320, 113, 20))
        self.duzenlencekobje_id.setText("")
        self.duzenlencekobje_id.setObjectName("duzenlencekobje_id")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(1370, 290, 131, 16))
        self.label_5.setObjectName("label_5")
        self.tamam_button = QtWidgets.QPushButton(self.centralwidget)
        self.tamam_button.setGeometry(QtCore.QRect(1390, 410, 75, 23))
        self.tamam_button.setObjectName("tamam_button")
        self.tamam_button.clicked.connect(self.nesne_hareket_durum)
        self.line_3 = QtWidgets.QFrame(self.centralwidget)
        self.line_3.setGeometry(QtCore.QRect(1270, 440, 241, 20))
        self.line_3.setFrameShape(QtWidgets.QFrame.HLine)
        self.line_3.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_3.setObjectName("line_3")

        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(1390, 460, 121, 20))
        self.label_7.setObjectName("label_7")
        self.line = QtWidgets.QFrame(self.centralwidget)
        self.line.setGeometry(QtCore.QRect(1270, 540, 241, 20))
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(1360, 550, 131, 20))
        self.label_8.setObjectName("label_8")
        self.NOT_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.NOT_radiobutton.setGeometry(QtCore.QRect(1380, 570, 82, 17))
        self.NOT_radiobutton.setObjectName("NOT_radiobutton")
        self.BUFFER_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.BUFFER_radiobutton.setGeometry(QtCore.QRect(1380, 590, 82, 17))
        self.BUFFER_radiobutton.setObjectName("BUFFER_radiobutton")
        self.AND_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.AND_radiobutton.setGeometry(QtCore.QRect(1380, 610, 82, 17))
        self.AND_radiobutton.setObjectName("AND_radiobutton")
        self.OR_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.OR_radiobutton.setGeometry(QtCore.QRect(1380, 630, 82, 17))
        self.OR_radiobutton.setObjectName("OR_radiobutton")
        self.NAND_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.NAND_radiobutton.setGeometry(QtCore.QRect(1380, 650, 82, 17))
        self.NAND_radiobutton.setObjectName("NAND_radiobutton")
        self.NOR_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.NOR_radiobutton.setGeometry(QtCore.QRect(1380, 670, 82, 17))
        self.NOR_radiobutton.setObjectName("NOR_radiobutton")
        self.XOR_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.XOR_radiobutton.setGeometry(QtCore.QRect(1380, 690, 82, 17))
        self.XOR_radiobutton.setObjectName("XOR_radiobutton")
        self.XNOR_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.XNOR_radiobutton.setGeometry(QtCore.QRect(1380, 710, 82, 17))
        self.XNOR_radiobutton.setObjectName("XNOR_radiobutton")
        self.nesne_ekle_buton = QtWidgets.QPushButton(self.centralwidget)
        self.nesne_ekle_buton.setGeometry(QtCore.QRect(1440, 630, 75, 23))
        self.nesne_ekle_buton.setObjectName("nesne_ekle_buton")
        self.nesne_ekle_buton.clicked.connect(self.nesne_ekle)
        self.giris_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.giris_radiobutton.setGeometry(QtCore.QRect(1440, 570, 82, 17))
        self.giris_radiobutton.setObjectName("giris_radiobutton")
        self.cikis_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.cikis_radiobutton.setGeometry(QtCore.QRect(1440, 600, 82, 17))
        self.cikis_radiobutton.setObjectName("cikis_radiobutton")
        self.DUGUM_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.DUGUM_radiobutton.setGeometry(QtCore.QRect(1440, 670, 82, 17))
        self.DUGUM_radiobutton.setObjectName("DUGUM_radiobutton")
        self.calistir_buton = QtWidgets.QPushButton(self.centralwidget)
        self.calistir_buton.setGeometry(QtCore.QRect(1280, 250, 75, 23))
        self.calistir_buton.setObjectName("calistir_buton")
        self.calistir_buton.clicked.connect(self.baslat)
        self.durdur_buton = QtWidgets.QPushButton(self.centralwidget)
        self.durdur_buton.setGeometry(QtCore.QRect(1280, 280, 75, 23))
        self.durdur_buton.setObjectName("durdur_buton")
        self.durdur_buton.clicked.connect(self.durdur)
        self.reset_buton = QtWidgets.QPushButton(self.centralwidget)
        self.reset_buton.setGeometry(QtCore.QRect(1280, 310, 75, 23))
        self.reset_buton.setObjectName("reset_buton")
        self.reset_buton.clicked.connect(self.resetle)
        self.led_radiobutton = QtWidgets.QRadioButton(self.centralwidget)
        self.led_radiobutton.setGeometry(QtCore.QRect(1440, 700, 82, 17))
        self.led_radiobutton.setObjectName("led_radiobutton")
        self.verticalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(1310, 130, 161, 87))
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.alan2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_2)
        self.alan2.setContentsMargins(0, 0, 0, 0)
        self.alan2.setObjectName("alan2")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_3.setObjectName("label_3")
        self.alan2.addWidget(self.label_3)
        self.on2_radiobutton = QtWidgets.QRadioButton(self.verticalLayoutWidget_2)
        self.on2_radiobutton.setObjectName("on2_radiobutton")
        self.alan2.addWidget(self.on2_radiobutton)
        self.arka2_radiobutton = QtWidgets.QRadioButton(self.verticalLayoutWidget_2)
        self.arka2_radiobutton.setObjectName("arka2_radiobutton")
        self.alan2.addWidget(self.arka2_radiobutton)
        self.kablo_uc_no_diger = QtWidgets.QLineEdit(self.verticalLayoutWidget_2)
        self.kablo_uc_no_diger.setObjectName("kablo_uc_no_diger")
        self.alan2.addWidget(self.kablo_uc_no_diger)
        self.verticalLayoutWidget_3 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_3.setGeometry(QtCore.QRect(1320, 40, 151, 87))
        self.verticalLayoutWidget_3.setObjectName("verticalLayoutWidget_3")
        self.alan1 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_3)
        self.alan1.setContentsMargins(0, 0, 0, 0)
        self.alan1.setObjectName("alan1")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        font = QtGui.QFont()
        font.setUnderline(False)
        font.setStrikeOut(False)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.alan1.addWidget(self.label_2)
        self.arka1_radiobutton = QtWidgets.QRadioButton(self.verticalLayoutWidget_3)
        self.arka1_radiobutton.setObjectName("arka1_radiobutton")
        self.alan1.addWidget(self.arka1_radiobutton)
        self.on1_radiobutton = QtWidgets.QRadioButton(self.verticalLayoutWidget_3)
        self.on1_radiobutton.setObjectName("on1_radiobutton")
        self.alan1.addWidget(self.on1_radiobutton)
        self.kablo_uc_no = QtWidgets.QLineEdit(self.verticalLayoutWidget_3)
        self.kablo_uc_no.setObjectName("kablo_uc_no")
        self.alan1.addWidget(self.kablo_uc_no)
        self.bagla_buton = QtWidgets.QPushButton(self.centralwidget)
        self.bagla_buton.setGeometry(QtCore.QRect(1310, 220, 181, 23))
        self.bagla_buton.setObjectName("bagla_buton")
        self.bagla_buton.clicked.connect(self.photo_draw_baglanti)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.cizim_durum=False
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.objeler=[]
        self.scene=QGraphicsScene()
        self.scene.setSceneRect(-20, -20, 1280, 800)
        self.vies=QGraphicsView(self.scene)
        self.yerlestirme_alan.addWidget(self.vies)
        self.baglancaklar=[]
    
    def reset(self):
        for obje in self.objeler:
            if isinstance(obje,DraggableWidget):
                obje.inputlist=[]
                obje.output=0
            elif isinstance(obje,CikisWidget):
                obje.cikis_degeri=0
            elif isinstance(obje,LED_Widget):
                obje.gate_value_add(0)
                obje.update()
            elif isinstance(obje,DugumWidget):
                obje.inputlist=[]
            elif isinstance(obje,GirisWidget):
                obje.hat_degeri=1



    def baslat(self):
        self.reset()
        for obje in self.objeler:
            obje.yetki=False
        for obje in self.baglancaklar:
            obje[1].gate_value_add(obje[0].gate_get_out())
            try:

                obje[1].update()
            except AttributeError:
                pass
            for i in self.objeler:
                try:
                    i.update()
                except AttributeError:
                    pass

    def photo_draw_baglanti(self):    
        hedefobje1=None
        hedefobje2=None

        for i in self.objeler:
            if i.ticket_id==self.kablo_uc_no.text():
                hedefobje1=i
        for i in self.objeler:
            if i.ticket_id==self.kablo_uc_no_diger.text():
                hedefobje2=i
        if self.on1_radiobutton.isChecked():
            baslangic=hedefobje1.get_front_cordinat()
        elif self.arka1_radiobutton.isChecked():
            baslangic=hedefobje1.get_behind_cordinat()
        if self.on2_radiobutton.isChecked():
            bitis=hedefobje2.get_front_cordinat()
        elif self.arka2_radiobutton.isChecked():
            bitis=hedefobje2.get_behind_cordinat()
        line=QGraphicsLineItem(baslangic.x(),baslangic.y(),bitis.x(),bitis.y())
        pen = QPen(QColor("black"))
        pen.setWidth(2)
        line.setPen(pen)
        self.scene.addItem(line)

        self.baglancaklar.append([hedefobje1,hedefobje2])

        # self.resimciz.addLine(baslangic,bitis)
    def nesne_ekle(self):
        global AND_gate_number
        global OR_gate_number
        global Not_gate_number
        global Buffer_gate_number
        global NAND_gate_number
        global XNOR_gate_number
        global XOR_gate_number
        global NOR_gate_number
        global Giris_gate_number
        global cikis_gate_number
        global Dugum_number
        global led_number

        if self.AND_radiobutton.isChecked():
            
            deneme=DraggableWidget("AND.png",str(AND_gate_number))
            
            AND_gate_number+=1
            self.objeler.append(deneme)
        elif self.OR_radiobutton.isChecked():
            deneme=DraggableWidget("OR.png",str(OR_gate_number))
            OR_gate_number+=1
            self.objeler.append(deneme)
        elif self.NOT_radiobutton.isChecked():
            deneme=DraggableWidget("NOT.png",str(Not_gate_number))
            Not_gate_number+=1
            self.objeler.append(deneme)
        elif self.BUFFER_radiobutton.isChecked():
            deneme=DraggableWidget("BUFFER.png",str(Buffer_gate_number))
            Buffer_gate_number+=1
            self.objeler.append(deneme)
        elif self.NAND_radiobutton.isChecked():
            deneme=DraggableWidget("NAND.png",str(NAND_gate_number))
            NAND_gate_number+=1
            self.objeler.append(deneme)
        elif self.XNOR_radiobutton.isChecked():
            deneme=DraggableWidget("XNOR.png",str(XNOR_gate_number))
            XNOR_gate_number+=1
            self.objeler.append(deneme)
        elif self.XOR_radiobutton.isChecked():
            deneme=DraggableWidget("XOR.png",str(XOR_gate_number))
            XOR_gate_number+=1
            self.objeler.append(deneme)
        elif self.NOR_radiobutton.isChecked():
            deneme=DraggableWidget("NOR.png",str(NOR_gate_number))
            NOR_gate_number+=1
            self.objeler.append(deneme)
        elif self.DUGUM_radiobutton.isChecked():
            deneme=DugumWidget("DUGUM.png",str(Dugum_number))
            Dugum_number+=1
            self.objeler.append(deneme)
        elif self.giris_radiobutton.isChecked():
            deneme=GirisWidget("G.png",str(Giris_gate_number))
            Giris_gate_number+=1
            self.objeler.append(deneme)
        elif self.cikis_radiobutton.isChecked():
            deneme=CikisWidget("C.png",str(cikis_gate_number))
            cikis_gate_number+=1
            self.objeler.append(deneme)
        elif self.led_radiobutton.isChecked():
            deneme=LED_Widget("PASİF_LED.png",str(led_number))
            led_number+=1
            self.objeler.append(deneme)
            
        try:
            self.scene.addWidget(deneme)
            
        except UnboundLocalError:
            pass
    def resetle(self):
        self.scene.clear()
        self.objeler.clear()

    def durdur(self):
        for i in self.objeler:
            if isinstance(i,LED_Widget):
                i.hat_degeri=0
                i.update()
            elif isinstance(i,CikisWidget):
                i.cikis_degeri=0
        

    def nesne_hareket_durum(self):
        self.scene
        hedefobje=None
        
        for i in self.objeler:
            if i.ticket_id==self.duzenlencekobje_id.text():
                hedefobje=i

        try:
            if self.duzenle_radio.isChecked():
                hedefobje.yetki=True
            elif self.sabitle_radio.isChecked():
                hedefobje.yetki=False 
        except AttributeError:
            pass          
     


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "BAĞLANTI "))
        self.label_4.setText(_translate("MainWindow", "DÜZENLEME MODU"))
        self.duzenle_radio.setText(_translate("MainWindow", "DÜZENLE"))
        self.sabitle_radio.setText(_translate("MainWindow", "SABİTLE"))
        self.label_5.setText(_translate("MainWindow", "DÜZENLENECEK OBJE ID"))
        self.tamam_button.setText(_translate("MainWindow", "TAMAM"))
        

        self.label_8.setText(_translate("MainWindow", "NESNE_EKLE"))
        self.NOT_radiobutton.setText(_translate("MainWindow", "NOT"))
        self.BUFFER_radiobutton.setText(_translate("MainWindow", "BUFFER"))
        self.AND_radiobutton.setText(_translate("MainWindow", "AND"))
        self.OR_radiobutton.setText(_translate("MainWindow", "OR"))
        self.NAND_radiobutton.setText(_translate("MainWindow", "NAND"))
        self.NOR_radiobutton.setText(_translate("MainWindow", "NOR"))
        self.XOR_radiobutton.setText(_translate("MainWindow", "XOR"))
        self.XNOR_radiobutton.setText(_translate("MainWindow", "XNOR"))
        self.nesne_ekle_buton.setText(_translate("MainWindow", "EKLE"))
        self.giris_radiobutton.setText(_translate("MainWindow", "GİRİS"))
        self.cikis_radiobutton.setText(_translate("MainWindow", "CIKIS"))
        self.DUGUM_radiobutton.setText(_translate("MainWindow", "DUGUM"))
        self.calistir_buton.setText(_translate("MainWindow", "ÇALIŞTIR"))
        self.durdur_buton.setText(_translate("MainWindow", "DURDUR"))
        self.reset_buton.setText(_translate("MainWindow", "RESET"))
        self.led_radiobutton.setText(_translate("MainWindow", "LED"))
        self.label_3.setText(_translate("MainWindow", "    KABLO UCU DİĞER NUMARA"))
        self.on2_radiobutton.setText(_translate("MainWindow", "ÖN"))
        self.arka2_radiobutton.setText(_translate("MainWindow", "ARKA"))
        self.label_2.setText(_translate("MainWindow", "KABLO UCU NUMARASI"))
        self.arka1_radiobutton.setText(_translate("MainWindow", "ARKA"))
        self.on1_radiobutton.setText(_translate("MainWindow", "ÖN"))
        self.bagla_buton.setText(_translate("MainWindow", "BAĞLA"))


if __name__ == "__main__":
    
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
