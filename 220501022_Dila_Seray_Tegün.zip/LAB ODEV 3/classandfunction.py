import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout,QLabel,QPushButton,QLineEdit,QInputDialog,QGraphicsLineItem
from PyQt5.QtGui import QMouseEvent, QPainter, QPen,QPixmap,QColor,QFont
from PyQt5.QtCore import Qt,QRect,QPoint
from PIL import Image, ImageDraw, ImageFont
import os

def AND_gate(sonuc):
    
    return all(sonuc)

def OR_gate(sonuc):
    return any(sonuc)

def NOT_gate(input):
    return not input

def NOR_gate(sonuc):
    return NOT_gate(OR_gate(sonuc))

def NAND_gate(sonuc):
    return NOT_gate(AND_gate(sonuc))

def BUFFER_gate(sonuc):
    return sonuc
def XOR_gate(sonuc):
    
    return sum(sonuc) == 1
def XNOR_gate(sonuc):
    return NOT_gate(XOR_gate(sonuc))

class DrawingArea(QWidget):
    def __init__(self):
        super().__init__()
        self.is_drawing = False
        self.last_point = None
        self.lines = []

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setPen(QPen(Qt.black, 2, Qt.SolidLine))
        
        for line in self.lines:
            painter.drawLine(line[0], line[1])

    def mousePressEvent(self, event):
        
        if self.is_drawing:
            self.last_point = event.pos()



    def mouseMoveEvent(self, event):
        if self.is_drawing and self.last_point:
            current_point = event.pos()
            self.lines.append((self.last_point, current_point))
            self.last_point = current_point
            self.repaint()

    def mouseReleaseEvent(self, event):
        if self.is_drawing:
            self.last_point = None

    def toggle_drawing(self):
        self.is_drawing = not self.is_drawing

    def addLine(self, start_point, end_point):
        self.lines.append((start_point, end_point))
        self.update()
        

import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QLabel, QDialog

class Dialog(QDialog):
    def __init__(self, text):
        super().__init__()
        self.setWindowTitle("HAT")
        self.setFixedSize(150,100)
        layout = QVBoxLayout()
        label = QLabel(text)
        layout.addWidget(label)
        
        self.setLayout(layout)




def photo_writing(photo,number,size,yazma_mod=True):
    
    if not yazma_mod:
        return QPixmap(photo).scaled(90,90)
    image_path = photo  
    image = Image.open(image_path)
    draw = ImageDraw.Draw(image)

    
    text = photo.strip(".png")+str(number)
    font_path = "PaintFont.ttf" 
    font = ImageFont.truetype(font_path, size)  

   
    text_width, text_height = draw.textsize(text, font)

  
    image_width, image_height = image.size

    
    x = (image_width - text_width) // 2 
    y = (image_height - text_height) // 2 

    
    draw.text((x, y), text, font=font, fill="orange")

    image.save(photo.strip(".png")+"No.png")  

    save=QPixmap(photo.strip(".png")+"No.png").scaled(80, 80)

    os.remove(photo.strip(".png")+"No.png")
    
    return save


def photo_control(photo,number,yazma_modd=True):
    if photo.strip(".png") =="NOT":
        
        return photo_writing(photo,number,42,yazma_mod=yazma_modd)
    elif photo.strip(".png") =="AND":
        
        return photo_writing(photo,number,50,yazma_mod=yazma_modd)
    elif photo.strip(".png") =="OR":
        
        return photo_writing(photo,number,59,yazma_mod=yazma_modd)
    elif photo.strip(".png") =="NAND":
        
        return photo_writing(photo,number,55,yazma_mod=yazma_modd)
    elif photo.strip(".png") =="NOR":
        
        return photo_writing(photo,number,50,yazma_mod=yazma_modd)
    elif photo.strip(".png")=="BUFFER":
        
        return photo_writing(photo,number,33,yazma_mod=yazma_modd)
    elif photo.strip(".png")=="XOR":
        
        return photo_writing(photo,number,55,yazma_mod=yazma_modd)
    elif photo.strip(".png")=="XNOR":
        
        return photo_writing(photo,number,55,yazma_mod=yazma_modd)
    elif photo.strip(".png")=="DUGUM":
        return photo_writing(photo,number,50,yazma_mod=yazma_modd)
    elif photo.strip(".png")=="G":
        return photo_writing(photo,number,50,yazma_mod=yazma_modd)
    elif photo.strip(".png")=="C":
        return photo_writing(photo,number,50,yazma_mod=yazma_modd)
    elif photo.strip(".png")=="PASİF_LED":
        return photo_writing(photo,number,50,yazma_mod=False)
class CustomLabel(QLabel):
    def __init__(self, image_path, x, y, width, height, parent=None):
        super().__init__(parent)
        self.image_path = image_path
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.pixmap = QPixmap(self.image_path)


class DraggableWidget(QWidget):
    def __init__(self,photo,id, parent=None):
        super().__init__(parent)
        self.setFixedSize(90,90)
        self.nowkordinat_topleft=self.geometry().topLeft()
        self.nowkordinat_topright=self.geometry().topRight()
        self.kablo_bosluk_payi=10
        self.tur=photo
        self.operator_id=id
        self.ticket_id=self.tur.strip(".png")+str(self.operator_id)
        self.setMouseTracking(True)
        self.yetki=True
        self.label = QLabel(self)
        self.label.setPixmap(photo_control(photo,self.operator_id))  # Resmi boyutlandırarak ekle
        self.label.setGeometry(0, 0, 100,100)  # Boyut ve konum ayarla
        self.layouts = QVBoxLayout(self)
        self.label.setAlignment(Qt.AlignCenter)
        self.layouts.addWidget(self.label)
        
        
        self.inputlist=[]
        self.output=0
        if photo.strip(".png")=="NOT":
            self.islemci=NOT_gate
        
        elif photo.strip(".png")=="BUFFER":
            self.islemci=BUFFER_gate
        elif photo.strip(".png")=="AND":
            self.islemci=AND_gate
        elif photo.strip(".png")=="OR":
            self.islemci=OR_gate
        elif photo.strip(".png")=="NAND":
            self.islemci=NAND_gate
        elif photo.strip(".png")=="NOR":
            self.islemci=NOR_gate
        elif photo.strip(".png")=="XOR":
            self.islemci=XOR_gate
        elif photo.strip(".png")=="XNOR":
            self.islemci=XNOR_gate

    def mouseDoubleClickEvent(self, event):
        
        hat_sayisi=Dialog(" bağlı hat sayisi " +str(len(self.inputlist)))
        hat_sayisi.exec_()

    def get_front_cordinat(self):


        point =QPoint(self.nowkordinat_topleft.x(),self.nowkordinat_topleft.y()-self.kablo_bosluk_payi)
        point =QPoint(self.nowkordinat_topright.x(),self.nowkordinat_topright.y()+50)
        self.kablo_bosluk_payi+=10
        return point

    def get_behind_cordinat(self):
        point =QPoint(self.nowkordinat_topleft.x(),self.nowkordinat_topleft.y()+self.kablo_bosluk_payi)

        self.kablo_bosluk_payi+=10
        return point

    def gate_value_add(self,value):
        self.inputlist.append(value)

    def update(self):
        try:
            if self.tur.strip(".png")=="NOT" or self.tur.strip(".png")=="BUFFER":
                self.output=self.islemci(self.inputlist[0])
            else:
                self.output=self.islemci(self.inputlist)
        except IndexError:
            pass
    def gate_get_out(self):

        
        return  self.output
      
    def set_image(self, image_path):
        
        pixmap = QPixmap(image_path)
        
        self.label.setPixmap(pixmap)
        
        self.label.setScaledContents(True)


    def mousePressEvent(self, event):

        if event.buttons() == Qt.LeftButton and self.yetki:
            self.offset = event.pos()

    def mouseMoveEvent(self, event):
        self.nowkordinat_topleft=self.geometry().topLeft()
        self.nowkordinat_topright=self.geometry().topRight()
        if event.buttons() == Qt.LeftButton and self.yetki:
            widget_pos = self.mapToParent(event.pos() - self.offset)
            self.move(widget_pos)

class DugumWidget(DraggableWidget):
    def __init__(self,photo,id,parent=None):
        super().__init__(photo,id,parent)
        self.outputlist=[]
    def gate_value_add(self, value):
        if len(self.inputlist)!=1:

            self.inputlist.append(value)
    def gate_get_out(self):
        return self.inputlist[0]
    
    # def get_front_cordinat(self):
    #     return super().get_behind_cordinat()
    # def get_behind_cordinat(self):
    #     return super().get_front_cordinat()
class GirisWidget(DraggableWidget):
    def __init__(self, photo, id, parent=None):
        super().__init__(photo, id, parent)
        self.hat_degeri=1

    def gate_value_add(self,newdeger):

        self.hat_degeri=newdeger
    def mouseDoubleClickEvent(self, event):
        try:
            
            text, ok = QInputDialog.getText(self, "Değer gir", "Mevcut Değer {}".format(self.hat_degeri))
            if int(text)==0 or int(text)==1:
                self.hat_degeri=int(text)
        except ValueError:
            pass
    
    def gate_get_out(self):
        return self.hat_degeri
    
class CikisWidget(DraggableWidget):
    def __init__(self, photo, id, parent=None):
        super().__init__(photo, id, parent)
        self.cikis_degeri=0
    def gate_value_add(self,newdeger):

        self.cikis_degeri=newdeger
    def gate_get_out(self):
        return self.cikis_degeri
    def mouseDoubleClickEvent(self, event):
        
        hat_degeri=Dialog(" Anlık Hat Değeri " +str(self.gate_get_out()))
        hat_degeri.exec_()



class LED_Widget(DraggableWidget):
    def __init__(self, photo, id, parent=None):
        super().__init__(photo, id, parent)
        self.hat_degeri=0
        self.ticket_id="LED"+str(id)

    def gate_value_add(self, value):
        self.hat_degeri=value
    
    def update(self):
        
        if self.hat_degeri==1:
            self.label.setPixmap(QPixmap("AKTİF_LED.png").scaled(90,90))
        else:
            self.label.setPixmap(QPixmap("PASİF_LED.png").scaled(90,90))

    def mouseDoubleClickEvent(self, event):
        led_id=Dialog("LED ID: {}{}".format("LED",self.operator_id))
        led_id.exec_()

